【Free version】VRoid・VRM Steam Rabbit（Pike's Creative Shop）

Thank you for purchasing this product.
Please make sure to read this section before using the product.

This file is for the model set presented below.
【VRoid】BOOTHにてVRoidStudio用『Steam Rabbit』販売中（無料有）-ぴケの創作屋さん（　https://kodaiga.xyz/2023/01/12/　）

-----------------------------------------------------------
credit


creator：ぴケ/Pike
Homepage：　https://kodaiga.xyz/　
BOOTH：　https://pike8341.booth.pm/　
instagram：　https://www.instagram.com/pike_8341/　
Twitter：　https://twitter.com/pike_8341　
pixiv:　https://www.pixiv.net/users/13191396　
Marshmallow：　https://marshmallow-qa.com/pike_yamazukin?utm_medium=url_text&utm_source=promotion　

Please feel free to contact us via the above or other means.

※We strictly refuse to reproduce or quote the content of your transmission without your permission.
※Please be assured that we will not quote or expose your correspondence without your permission.


-----------------------------------------------------------
Notes.


・The copyright is not destroyed.
・This file is for the official version of VRoidStudio.
・The products and readme may be updated without notice.
・Please back up your data by yourself.


【Regarding malfunction】
Noise may appear on costumes in some VRM services．

This is due to the translucent image texture, so this can be solved by selecting this product in the 'Costume' section of VRoidStudio, 
moving to 'Edit Texture' and then hiding the top 'image' layer.

-----------------------------------------------------------
Terms of use

〇Free use.
　・Free commercial use (distribution permitted) of models and other objects using this product.
　・Modification of the product, free of charge and commercial use (may be distributed) of models etc. using the data.
　・Publication of works using modified data of products and goods, and use in support services and commissions.

△What we would like to ask you to do
　・Redistribution of modified data (both free of charge and commercial use).
　・If you wish to remove the credit notation.
　・If you are unsure whether the purpose of use does not contravene the terms of use.

× What you must not do.
　・Redistribute this data as it is (whether free of charge or for compensation).
　・Use for the purpose of political or religious activities or defamation of others.
　・Self-created statements.
　・Use contrary to public order and morals.

◆About credit notation
　・Please write in the explanation column or other places that it was produced by “ぴケの創作屋さん（Pike’s Creative Shop）” or “ぴケ/Pike” when you use it.
　・The link is optional, but we would appreciate it if you could link to our website.

《If you want to use the product in a metaverse such as VRchat or Cluster, or in the main costume of your VTuber activity》
If you write the credit in the description section of your character, avatar or channel, or mention Pike’s name when asked, it’s no problem.
Please give credit when submitting photos.

《Use for sensitive content》
Basically, you may use sexual descriptions and violent descriptions as long as they do not violate the terms of use.
Please include a credit statement in the same manner as for other purposes of use.
If there are rules or restrictions in each service or community, please give priority to those rules or restrictions.



【If you want to use your product as something other than a 3D avatar】

〇Free use.
　・Both the free and paid versions of the design may be used freely.
　・Basically, you can use it as long as you use common sense.

△What we would like to ask you to do
　・Distribution of characters used.（both free of charge and commercial use）
　・If you are unsure whether the purpose of use does not contravene the terms of use.
　・If you want to create a 3D avatar of a character using our design without using Pike’s product.

× What you must not do.
　・Redistribute the design as is.（whether free of charge or for compensation）
　・Use for the purpose of political or religious activities or defamation of others.
　・Self-created statements.
　・Use contrary to public order and morals.

●If you wish to depict it as a background or item
Filling in the credits is optional, so please give Pike’s name when asked.

●If you want to portray a character design as the main focus
Credit notation required.

●If you want to use it as the main costume for your own original character, etc.
Please indicate credits in the character’s introduction section or elsewhere.


-----------------------------------------------------------
Disclaimer.

Pique is not responsible for any problems or trouble that may occur in the use of this product.
Please use the product at your own risk.


-----------------------------------------------------------
file contents

・【無料版 Free】VRoid・VRM Steam Rabbit（ぴケの創作屋さん）　（Zip）
　　│
　　│unzip
　　↓
　folder
・【無料版 Free】VRoid・VRM Steam Rabbit（ぴケの創作屋さん）
│
│　text
├・readme
├・readme(ENG)
│
│　URL
├・利用規約 Teams of use
│　
│　VRoid
├・Steam Rabbit Black outer
│
│　folder
├・Customitem
│├・SR hat Black
│└・SR outer black
│
│　folder
├・vrm
│└・Steam Rabbit Black outer
│
│　folder
├・tex
│├・hair
││└・hair 1 ~ 5
││
│├・image
││└・image 1
││
│└・coat black
│
│　folder
├・guide
│└・coat
│
│　folder
└・default tex
　├・coat
　└・hair


-----------------------------------------------------------
Product details

・Steam Rabbit Black outer

vrm
texture

-----------------------------------------------------------
How to load a model


・How to load in VRoid files

Open VRoidStudio and select "XX.VRoid" of this product from "Open" in the upper right corner.
Each of them is saved in " Outfit" "Hairstyle", so please save the product as a preset.


・How to import as Customitem

Open VRoidStudio, select the model of your choice, 
 select "Custom" -> "Import", and import the model from the "Customitem" folder of the product.


-----------------------------------------------------------