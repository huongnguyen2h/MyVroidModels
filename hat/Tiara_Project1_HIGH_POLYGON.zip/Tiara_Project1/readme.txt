ティアラ プロジェクト 1 ( Tiara Project 1 )
▲5798

マテリアル (3)
・メイン宝石
・サブ宝石
・フレーム

テクスチャ (0)

メッシュ (6)
・メイン宝石
・メイン宝石ベース
・サブ宝石
・サブ宝石ベース
・レース
・フレーム

BlendShape (0)

ご購入ありがとうございます
このアクセサリはliltoonを利用してます
インポートの上ご利用ください

・ライセンス(JA)
組み込んだ、取り出せない状態での再配布を許可します。
政治、宗教利用を除いて基本的に何してもいいです。
ただし、自作発言は不可。

・License(EN)
You are allowed to redistribute the software without the ability to extract it once it has been incorporated.
Generally, you can use it for any purpose except for political or religious use.
However, claiming authorship of the 3d model is not allowed.

制作 : @fivezett